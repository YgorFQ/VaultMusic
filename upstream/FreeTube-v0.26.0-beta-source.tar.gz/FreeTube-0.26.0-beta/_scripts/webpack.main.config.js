const path = require('path')
const webpack = require('webpack')
const MinimizerPlugin = require('minimizer-webpack-plugin')

const isDevMode = process.env.NODE_ENV === 'development'

/** @type {import('webpack').Configuration} */
const config = {
  name: 'main',
  mode: process.env.NODE_ENV,
  devtool: isDevMode ? 'eval-cheap-module-source-map' : false,
  entry: {
    main: path.join(__dirname, '../src/main/index.js'),
  },
  module: {
    generator: {
      json: {
        JSONParse: false
      }
    }
  },
  resolve: {
    alias: {
      // electron-context-menu only needs mime-db for its "save as" feature.
      // As we only activate the save image and save as image features,
      // we can remove all other mimetypes, as they will never get used.
      // Which results in quite a significant reduction in file size.
      //
      // Only the extensions field is needed, see: https://github.com/kevva/ext-list/blob/v2.2.2/index.js
      'mime-db$': path.join(__dirname, 'image-extensions-only-mime-db.json')
    }
  },
  // webpack defaults to only optimising the production builds, so having this here is fine
  optimization: {
    minimizer: [
      new MinimizerPlugin({
        test: /\.js(?:on)?(\?.*)?$/i,
        minify: [
          {
            implementation: MinimizerPlugin.jsonMinify
          },
          {
            implementation: MinimizerPlugin.terserMinify,
            options: {
              compress: {
                // webpack sets passes to 2 in its default minimizer config too
                passes: 2
              }
            }
          }
        ]
      })
    ]
  },
  node: {
    __dirname: isDevMode,
    __filename: isDevMode
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.platform': `'${process.platform}'`,
      'process.env.IS_ELECTRON_MAIN': true
    })
  ],
  output: {
    filename: '[name].js',
    libraryTarget: 'commonjs2',
    path: path.join(__dirname, '../dist'),
    copy: isDevMode
      ? undefined
      : [
          {
            from: 'static',
            to: 'static',
            globOptions: {
              ignore: [
                '**/.*',
                'static/{locales,pwabuilder-sw.js,manifest.json}'
              ]
            }
          }
        ]
  },
  target: 'electron-main',
}

module.exports = config
